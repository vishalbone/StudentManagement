﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement
{
    class Node
    {
        public string name;
        public int classno, stuID,subno;
        public double avg,total;
        public int[] marks;
        public Node nextadd;

        public Node()
        {
            Console.WriteLine("Enter the student name");
            name = Console.ReadLine();
            Console.WriteLine("Enter the class Number");
            classno = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number of subjects");
            subno = int.Parse(Console.ReadLine());
            marks = new int[subno];
            for(int i=0; i<marks.Length; i++)
            {
                Console.WriteLine("Enter the marks of subjects");
                marks[i] = int.Parse(Console.ReadLine());
                total += marks[i];
            }
            Console.WriteLine();
        }
        public void display()
        {
            Console.WriteLine("_______________Record___________________");
            Console.WriteLine("Student Name = " + name);
            Console.WriteLine("Student class = " + classno);
            avg = total / subno;
            if (avg >= 80)
            {
                Console.WriteLine("Average marks is = " + avg);
                Console.WriteLine("Result is Distinction ");
            }
            else if (avg >= 60)
            {
                Console.WriteLine("Average marks is = " + avg);
                Console.WriteLine("Result is First Class");
            }
            else if (avg >= 35)
            {
                Console.WriteLine("Average marks is = " + avg);
                Console.WriteLine("Result is Pass");
            }
            else
            {
                Console.WriteLine("Average marks is = " + avg);
                Console.WriteLine("Result is Fail");
            }
            Console.WriteLine();
        }
    }
    class student
    {
        public Node head;
        public student()
        {
            head = null;
        }
        public void newAddmission()
        {
            Node newstud = new Node();
            if (head == null)
            {
                head = newstud;
                newstud.stuID++;
            }
            else
            {
                newstud.nextadd = head;
                head = newstud;
                newstud.stuID++;
            }
        }
        public void res()
        {
            if(head==null)
                Console.WriteLine("No student in the class");
            else
            {
                Node temp = head;
                while(temp!=null)
                {
                    temp.display();
                    temp = temp.nextadd;
                }
            }
        }
        public void sterngth()
        {
            int count = 0;
            Node temp = head;
            while(temp!=null)
            {
                Console.WriteLine("Student name = " + temp.name);
                count++;
                temp = temp.nextadd;
            }
            Console.WriteLine("Total Strength of the class  = " + count);
            Console.WriteLine();
        }
        public void perticularstuinfo(string name)
        {
            if(head==null)
                Console.WriteLine("No Student in the class");
            else
            {
                Node temp = head;
                while(temp!=null)
                {
                    if(temp.name==name)
                    {
                        temp.display();
                        break;
                    }
                    temp = temp.nextadd;
                }
                Console.WriteLine("Student not exist in the class");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement
{
    class Program1
    {
        static void Main(string[] args)
        {
            student ob = new student();
            string username;
            long password;
            int ch,flag=0;
            string name;
            Console.WriteLine("Enter the User name And Password for login");
            Console.Write("User Name = ");
            username = Console.ReadLine();
            Console.Write("Password = ");
            password = long.Parse(Console.ReadLine());
            if (username == "Admin" && password == 123456)
            {
                while (flag == 0)
                {

                    Console.WriteLine("\nLog in Successfully\n");
                    Console.WriteLine("Press 1 for new Admission");
                    Console.WriteLine("Press 2 for Result");
                    Console.WriteLine("Press 3 for Strength Of Class and student details");
                    Console.WriteLine("Press 4 for to get perticular student information");
                    Console.WriteLine("Press 5  for Exit");
                    Console.WriteLine("__________________________________________________");
                    Console.WriteLine("Enter the choice");
                    ch = int.Parse(Console.ReadLine());

                    switch (ch)
                    {
                        case 1: ob.newAddmission(); break;
                        case 2: ob.res(); break;
                        case 3: ob.sterngth(); break;
                        case 4:
                            Console.WriteLine("Enter the student name");
                            name = Console.ReadLine();
                            ob.perticularstuinfo(name); break;
                        case 5: flag = 1; break;
                        default: Console.WriteLine("Invalid choice"); break;
                    }
                }
                
            }
            else
            {
                Console.WriteLine("Invalid User Name or Password");
            }
        }
    }
}
